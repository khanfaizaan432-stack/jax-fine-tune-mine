# JAXFixBench GitHub Miner Scaffold

Automates the mining pipeline for XLADoctor/JAXFixBench:

1. Discover star-ranked public JAX/Flax/Optax/XLA repos.
2. Build a filtered clone plan.
3. Clone a capped number of repos.
4. Extract JAX-rich snippets.
5. Score and clean snippets.
6. Mine pattern hits: `jax.jit`, `jax.vmap`, `.at[].set`, `lax.cond`, `lax.scan`, PRNG splitting, Flax, Optax, pmap/sharding.
7. Build repo-grounded synthetic mutation cases.
8. Validate broken/fixed code pairs.
9. Upload JSON/JSONL artifacts.

## Setup

Add a repository secret named `GITHUB_TOKEN`, then run:

Actions → **Mine JAXFixBench Sources** → Run workflow.

## Outputs

Artifacts include:

- `jax_repo_candidates_final.jsonl`
- `jax_repo_clone_plan.json`
- `public_jax_repo_snippets_clean.jsonl`
- `jax_pattern_hits.jsonl`
- `jax_pattern_summary.json`
- `repo_grounded_mutation_cases.jsonl`
- `repo_grounded_mutation_validation_report.json`
- `repo_grounded_mutation_cases_passed.jsonl`
- `MANIFEST.json`

Do not fine-tune on raw snippets directly. Use them as source evidence / RAG, and train mostly on validated mutation cases + curated docs/Q&A/issue rows.
