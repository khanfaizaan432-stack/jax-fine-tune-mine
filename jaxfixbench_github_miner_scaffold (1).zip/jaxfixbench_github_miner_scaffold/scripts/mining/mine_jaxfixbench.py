#!/usr/bin/env python3
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time
from collections import Counter, defaultdict
from pathlib import Path

import requests

BUCKETS = {
    "jax_general": ['jax in:name,description,readme language:Python stars:>5 archived:false fork:false', '"import jax" in:readme language:Python stars:>5 archived:false fork:false'],
    "jax_jit": ['"jax.jit" in:readme language:Python stars:>3 archived:false fork:false', '"@jax.jit" in:readme language:Python stars:>3 archived:false fork:false', '"jit" "jax" in:readme language:Python stars:>3 archived:false fork:false'],
    "jax_vmap": ['"jax.vmap" in:readme language:Python stars:>3 archived:false fork:false', '"vmap" "jax" in:readme language:Python stars:>3 archived:false fork:false'],
    "flax": ['"flax.linen" in:readme language:Python stars:>3 archived:false fork:false', 'flax in:name,description,readme language:Python stars:>3 archived:false fork:false'],
    "optax": ['optax in:name,description,readme language:Python stars:>3 archived:false fork:false', '"import optax" in:readme language:Python stars:>3 archived:false fork:false'],
    "xla_stablehlo": ['xla in:name,description,readme language:Python stars:>3 archived:false fork:false', 'stablehlo in:name,description,readme stars:>1 archived:false fork:false', '"XLA" "JAX" in:readme language:Python stars:>3 archived:false fork:false'],
}

KEEP_EXTS = {".py", ".md", ".rst", ".ipynb", ".mlir", ".hlo"}
EXTRACT_KEYWORDS = ["import jax", "jax.jit", "@jax.jit", "@jit", "jax.vmap", "vmap(", "jax.grad", "jax.value_and_grad", "lax.scan", "jax.lax.scan", "lax.cond", "jax.lax.cond", "jax.random", "PRNGKey", "flax.linen", "import flax", "optax", "pmap", "pjit", "sharding", "xla", "stablehlo", "mlir"]
BAD_PATH_BITS = [".git", "__pycache__", "site-packages", "dist-info", "build/", "node_modules", ".venv", "venv", "wandb/", "checkpoints/", "outputs/", "data/", "datasets/"]

POSITIVE_PATTERNS = {
    "import_jax": r"\bimport\s+jax\b",
    "from_jax": r"\bfrom\s+jax\b",
    "jax_numpy": r"\bimport\s+jax\.numpy\s+as\s+jnp\b|\bjnp\.",
    "jax_jit": r"\bjax\.jit\b|@jax\.jit\b|@jit\b",
    "jax_vmap": r"\bjax\.vmap\b|\bvmap\(",
    "jax_grad": r"\bjax\.grad\b|\bjax\.value_and_grad\b",
    "jax_lax": r"\bjax\.lax\b|\blax\.scan\b|\blax\.cond\b|\blax\.while_loop\b",
    "jax_random": r"\bjax\.random\b|\bPRNGKey\b|\brandom\.split\b",
    "flax": r"\bflax\b|\bflax\.linen\b|\bimport\s+flax\b",
    "optax": r"\boptax\b|\bimport\s+optax\b",
    "pmap_pjit": r"\bpmap\b|\bpjit\b|\bsharding\b|\bPartitionSpec\b",
}
NEGATIVE_PATTERNS = {
    "cuda_only": r"\bcuda\b|\bcutlass\b|\bcutedsl\b|\btriton\b",
    "tensorflow_only": r"\btensorflow\b|\btf\.",
    "pytorch_only": r"\btorch\b|\bpytorch\b",
    "aitemplate": r"\baitemplate\b|\bAITemplate\b",
    "generic_mlir_only": r"\bmlir\b|\bstablehlo\b|\bxla\b",
}

PATTERNS = {
    "functional_update_at": [r"\.at\[[^\]]+\]\.set\(", r"\.at\[[^\]]+\]\.add\(", r"\.at\[[^\]]+\]\.multiply\(", r"\.at\[[^\]]+\]\.divide\("],
    "jit_static_argnums": [r"jax\.jit\([^)]*static_argnums\s*=", r"jax\.jit\([^)]*static_argnames\s*=", r"@functools\.partial\(\s*jax\.jit[^)]*static_argnums\s*=", r"@functools\.partial\(\s*jax\.jit[^)]*static_argnames\s*="],
    "plain_jit": [r"@jax\.jit\b", r"jax\.jit\("],
    "lax_cond": [r"lax\.cond\(", r"jax\.lax\.cond\("],
    "lax_scan": [r"lax\.scan\(", r"jax\.lax\.scan\("],
    "vmap": [r"jax\.vmap\(", r"\bvmap\("],
    "random_split": [r"jax\.random\.split\(", r"random\.split\(", r"jax\.random\.PRNGKey\(", r"PRNGKey\("],
    "pmap_pjit_sharding": [r"jax\.pmap\(", r"\bpmap\(", r"\bpjit\(", r"PartitionSpec", r"NamedSharding", r"Mesh\("],
    "optax_update": [r"optax\.", r"\.update\([^)]*params", r"apply_updates\("],
    "flax_module": [r"flax\.linen", r"import flax\.linen as nn", r"class\s+\w+\(nn\.Module\)", r"@nn\.compact"],
}

MAX_PER_PATTERN = {"functional_update_at": 80, "lax_cond": 50, "lax_scan": 50, "jit_static_argnums": 70, "vmap": 100, "random_split": 100, "pmap_pjit_sharding": 80, "optax_update": 80, "flax_module": 80, "plain_jit": 80}


def jdump(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding="utf-8")


def read_jsonl(path):
    p = Path(path)
    if not p.exists(): return []
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def write_jsonl(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows) + ("\n" if rows else ""), encoding="utf-8")


def gh_headers():
    h = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
    tok = os.environ.get("GITHUB_TOKEN")
    if tok: h["Authorization"] = f"Bearer {tok}"
    return h


def cmd_discover(args):
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    checkpoint = out / "jax_repo_candidates_checkpoint.jsonl"
    final = out / "jax_repo_candidates_final.jsonl"
    repo_map = {r["repo"]: r for r in read_jsonl(checkpoint)}
    for bucket, queries in BUCKETS.items():
        current = {k for k, v in repo_map.items() if bucket in v.get("buckets", [])}
        print("BUCKET", bucket, "starting", len(current))
        for q in queries:
            if len(current) >= args.target_per_bucket: break
            for page in range(1, args.max_pages_per_query + 1):
                if len(current) >= args.target_per_bucket: break
                r = requests.get("https://api.github.com/search/repositories", headers=gh_headers(), params={"q": q, "sort": "stars", "order": "desc", "per_page": 50, "page": page}, timeout=30)
                if r.status_code in (403, 429):
                    print("rate limited", r.status_code, r.text[:300], file=sys.stderr)
                    write_jsonl(final, sorted(repo_map.values(), key=lambda x: x.get("stars") or 0, reverse=True)); return
                r.raise_for_status(); items = r.json().get("items", [])
                for item in items:
                    repo = item["full_name"]; size_kb = item.get("size") or 0
                    if size_kb > 300000: continue
                    lic = item.get("license") or {}
                    if repo in repo_map:
                        repo_map[repo]["buckets"] = sorted(set(repo_map[repo].get("buckets", [])) | {bucket})
                        repo_map[repo]["matched_queries"] = sorted(set(repo_map[repo].get("matched_queries", [])) | {q})
                    else:
                        row = {"repo": repo, "html_url": item.get("html_url"), "clone_url": item.get("clone_url"), "description": item.get("description"), "stars": item.get("stargazers_count"), "forks": item.get("forks_count"), "language": item.get("language"), "size_kb": size_kb, "license_key": lic.get("key"), "license_name": lic.get("name"), "updated_at": item.get("updated_at"), "pushed_at": item.get("pushed_at"), "default_branch": item.get("default_branch"), "buckets": [bucket], "matched_queries": [q], "source": "github_repository_search_star_ranked"}
                        repo_map[repo] = row
                        with checkpoint.open("a", encoding="utf-8") as f: f.write(json.dumps(row, ensure_ascii=False)+"\n")
                    current.add(repo)
                    if len(current) >= args.target_per_bucket: break
                print(bucket, len(current), "total", len(repo_map)); time.sleep(4)
    write_jsonl(final, sorted(repo_map.values(), key=lambda x: x.get("stars") or 0, reverse=True)); print("saved", final, len(repo_map))


def cmd_plan(args):
    out = Path(args.out_dir)
    rows = read_jsonl(out / "jax_repo_candidates_final.jsonl")
    allowed = {"apache-2.0", "mit", "bsd-2-clause", "bsd-3-clause", "isc", "mpl-2.0", None}
    by_bucket = defaultdict(list)
    for r in rows:
        if (r.get("size_kb") or 0) > 150000: continue
        if r.get("license_key") not in allowed: continue
        for b in r.get("buckets", []): by_bucket[b].append(r)
    selected, selected_by_bucket = {}, {}
    for b, br in by_bucket.items():
        chosen = sorted(br, key=lambda x: x.get("stars") or 0, reverse=True)[:50]
        selected_by_bucket[b] = [x["repo"] for x in chosen]
        for x in chosen: selected[x["repo"]] = x
    plan = {"selected_total_unique": len(selected), "selected_by_bucket": selected_by_bucket, "repos": list(selected.values())}
    jdump(out / "jax_repo_clone_plan.json", plan); print("selected unique repos:", len(selected))


def cmd_clone(args):
    out = Path(args.out_dir); root = out / "jax_public_repos"; root.mkdir(parents=True, exist_ok=True)
    plan = json.loads((out / "jax_repo_clone_plan.json").read_text(encoding="utf-8")); log_path = out / "jax_repo_clone_log.jsonl"
    done = {r["repo"] for r in read_jsonl(log_path) if r.get("status") in {"ok", "exists"}}
    cloned = 0
    with log_path.open("a", encoding="utf-8") as log:
        for i, r in enumerate(plan["repos"], 1):
            if cloned >= args.max_clones: break
            repo = r["repo"]
            if repo in done: continue
            target = root / repo.replace("/", "__")
            if target.exists(): row = {"repo": repo, "status": "exists"}; log.write(json.dumps(row)+"\n"); continue
            print("cloning", i, repo); res = subprocess.run(["git", "clone", "--depth", "1", "--filter=blob:none", r.get("clone_url") or f"https://github.com/{repo}.git", str(target)], capture_output=True, text=True, timeout=240)
            status = "ok" if res.returncode == 0 else "failed"; row = {"repo": repo, "status": status, "returncode": res.returncode, "stderr_tail": res.stderr[-1000:]}
            log.write(json.dumps(row, ensure_ascii=False)+"\n"); log.flush(); cloned += int(status == "ok"); time.sleep(2)
    print("cloned now", cloned)


def keep_file(path, text):
    p = str(path).lower()
    return path.suffix.lower() in KEEP_EXTS and not any(x in p for x in BAD_PATH_BITS) and len(text) <= 120000 and any(k.lower() in text.lower() for k in EXTRACT_KEYWORDS)


def cmd_extract(args):
    out = Path(args.out_dir); root = out / "jax_public_repos"; rows=[]; n=0
    for repo_dir in root.iterdir():
        if not repo_dir.is_dir(): continue
        repo = repo_dir.name.replace("__", "/")
        for path in repo_dir.rglob("*"):
            if not path.is_file(): continue
            try: text = path.read_text(encoding="utf-8", errors="ignore")
            except Exception: continue
            if keep_file(path, text):
                rows.append({"id": f"public_repo_snippet_{n:06d}", "source": "public_github_repo_snippet", "repo": repo, "path": str(path.relative_to(repo_dir)), "text": text[:20000], "metadata": {"license_note": "Public GitHub repository content. Preserve repo URL/license attribution before redistribution."}}); n+=1
    write_jsonl(out / "public_jax_repo_snippets.jsonl", rows); print("snippets", len(rows))


def hits(patterns, text):
    d={}
    for k,p in patterns.items():
        n=len(re.findall(p, text, flags=re.I|re.M))
        if n: d[k]=n
    return d


def score_row(row):
    text=row.get("text",""); pos=hits(POSITIVE_PATTERNS,text); neg=hits(NEGATIVE_PATTERNS,text); s=0
    s += 4*bool(pos.get("import_jax") or pos.get("from_jax")); s += 3*bool(pos.get("jax_numpy")); s += 5*bool(pos.get("jax_jit")); s += 5*bool(pos.get("jax_vmap")); s += 4*bool(pos.get("jax_grad")); s += 5*bool(pos.get("jax_lax")); s += 3*bool(pos.get("jax_random")); s += 4*bool(pos.get("flax")); s += 4*bool(pos.get("optax")); s += 3*bool(pos.get("pmap_pjit"))
    if any(x in row.get("path","").lower() for x in ["example","tutorial","notebook","test","train"]): s+=2
    if neg.get("aitemplate"): s-=10
    if neg.get("cuda_only") and not (pos.get("import_jax") or pos.get("from_jax")): s-=6
    if neg.get("generic_mlir_only") and not (pos.get("import_jax") or pos.get("from_jax") or pos.get("flax") or pos.get("optax")): s-=5
    row["jax_score"]=s; row["positive_hits"]=pos; row["negative_hits"]=neg; return row


def cmd_score(args):
    out=Path(args.out_dir); rows=[score_row(r) for r in read_jsonl(out/"public_jax_repo_snippets.jsonl")]
    write_jsonl(out/"public_jax_repo_snippets_scored.jsonl", sorted(rows, key=lambda x:x["jax_score"], reverse=True))
    clean=[r for r in rows if r["jax_score"]>=6 and (r["positive_hits"].get("import_jax") or r["positive_hits"].get("from_jax") or r["positive_hits"].get("jax_numpy") or r["positive_hits"].get("flax") or r["positive_hits"].get("optax"))]
    write_jsonl(out/"public_jax_repo_snippets_clean.jsonl", sorted(clean, key=lambda x:x["jax_score"], reverse=True)); print("clean", len(clean))


def line_window(text, pos, window=8):
    lines=text.splitlines(); run=0; hit=0
    for i,line in enumerate(lines):
        run += len(line)+1
        if run>=pos: hit=i; break
    return "\n".join(lines[max(0,hit-window):min(len(lines),hit+window+1)]).strip(), hit+1


def cmd_patterns(args):
    out=Path(args.out_dir); raw=[]
    for row in read_jsonl(out/"public_jax_repo_snippets_clean.jsonl"):
        text=row.get("text","")
        for pn, regs in PATTERNS.items():
            for rgx in regs:
                for m in re.finditer(rgx, text, flags=re.M):
                    sn, ln = line_window(text, m.start())
                    if len(sn)<20: continue
                    raw.append({"pattern": pn, "regex": rgx, "repo": row["repo"], "path": row["path"], "line": ln, "snippet": sn[:3000], "jax_score": row.get("jax_score"), "positive_hits": row.get("positive_hits",{}), "metadata": {"source_snippet_id": row.get("id"), "license_note": row.get("metadata",{}).get("license_note")}})
    dedup=[]; seen=set()
    for h in raw:
        key=(h["pattern"], h["repo"], h["path"], h["snippet"][:300])
        if key in seen: continue
        seen.add(key); h["id"]=f"jax_pattern_hit_{len(dedup):06d}"; dedup.append(h)
    write_jsonl(out/"jax_pattern_hits.jsonl", dedup)
    summary={"total_hits": len(dedup), "patterns": dict(Counter(h["pattern"] for h in dedup).most_common()), "repos": dict(Counter(h["repo"] for h in dedup).most_common(50))}
    jdump(out/"jax_pattern_summary.json", summary); print("pattern hits", len(dedup))


def cap_hits(out):
    hits=read_jsonl(out/"jax_pattern_hits.jsonl"); by=defaultdict(list)
    for h in hits: by[h["pattern"]].append(h)
    selected=[]
    for p, rows in by.items():
        rc=Counter(); kept=0
        for h in sorted(rows, key=lambda x:x.get("jax_score") or 0, reverse=True):
            if rc[h["repo"]]>=15: continue
            h["capped_id"]=f"jax_pattern_capped_{len(selected):06d}"; selected.append(h); rc[h["repo"]]+=1; kept+=1
            if kept>=MAX_PER_PATTERN.get(p,50): break
    write_jsonl(out/"jax_pattern_hits_capped.jsonl", selected); return selected


def case(cid, task, err, broken, fixed, root, expl, tags, h):
    return {"id": cid, "source": "repo_grounded_synthetic_mutation", "task_type": task, "error_type": err, "difficulty": "intermediate", "broken_code": broken, "fixed_code": fixed, "root_cause": root, "explanation": expl, "tags": tags, "source_evidence": {"repo": h["repo"], "path": h["path"], "line": h["line"], "pattern": h["pattern"], "snippet": h["snippet"][:1200]}, "messages": [{"role":"system","content":"You are XLADoctor, a JAX/XLA debugging assistant."},{"role":"user","content":f"Broken JAX code:\n```python\n{broken}\n```"},{"role":"assistant","content":f"Error type: {err}\n\nRoot cause: {root}\n\nFixed code:\n```python\n{fixed}\n```\n\nExplanation: {expl}"}]}


def cmd_mutations(args):
    out=Path(args.out_dir); selected=cap_hits(out); by=defaultdict(list)
    for h in selected: by[h["pattern"]].append(h)
    templates={
        "functional_update_at": (40,"jax_error_fix","JAX array immutability / item assignment error", "import jax.numpy as jnp\n\ndef update_value(x):\n    x[1] = 10.0\n    return x\n\nx = jnp.zeros((4,))\nprint(update_value(x))", "import jax.numpy as jnp\n\ndef update_value(x):\n    x = x.at[1].set(10.0)\n    return x\n\nx = jnp.zeros((4,))\nprint(update_value(x))", "JAX arrays are immutable, so direct item assignment is not allowed.", "Use x.at[index].set(value) to return an updated array.", ["jax","immutability","at_set"]),
        "lax_cond": (40,"jax_error_fix","TracerBoolConversionError", "import jax\nimport jax.numpy as jnp\n\n@jax.jit\ndef choose_sign(x):\n    if jnp.sum(x) > 0:\n        return x\n    return -x\n\nprint(choose_sign(jnp.array([1.0, -0.5])))", "import jax\nimport jax.numpy as jnp\n\n@jax.jit\ndef choose_sign(x):\n    return jax.lax.cond(jnp.sum(x) > 0, lambda y: y, lambda y: -y, x)\n\nprint(choose_sign(jnp.array([1.0, -0.5])))", "A Python if depends on a traced value inside jit.", "Use jax.lax.cond for traced branch conditions.", ["jax","jit","lax_cond"]),
        "vmap": (40,"jax_error_fix","vmap in_axes axis-size mismatch", "import jax\nimport jax.numpy as jnp\n\ndef add_bias(x,bias): return x+bias\nx=jnp.ones((3,4)); bias=jnp.ones((4,))\nprint(jax.vmap(add_bias, in_axes=(0,0))(x,bias))", "import jax\nimport jax.numpy as jnp\n\ndef add_bias(x,bias): return x+bias\nx=jnp.ones((3,4)); bias=jnp.ones((4,))\nprint(jax.vmap(add_bias, in_axes=(0,None))(x,bias))", "bias is shared, but in_axes maps over it.", "Use in_axes=(0, None) for shared arguments.", ["jax","vmap","in_axes"]),
        "jit_static_argnums": (40,"jax_error_fix","ConcretizationTypeError", "import jax\nimport jax.numpy as jnp\n\n@jax.jit\ndef make_range(n): return jnp.arange(n)\nprint(make_range(5))", "import functools, jax\nimport jax.numpy as jnp\n\n@functools.partial(jax.jit, static_argnames=(\"n\",))\ndef make_range(n): return jnp.arange(n)\nprint(make_range(5))", "n controls an array shape but is traced under jit.", "Mark shape-controlling args static.", ["jax","jit","static_argnames"]),
        "random_split": (40,"jax_best_practice_fix","PRNG key reuse", "import jax\nkey=jax.random.PRNGKey(0)\na=jax.random.normal(key,(3,)); b=jax.random.uniform(key,(3,))\nprint(a); print(b)", "import jax\nkey=jax.random.PRNGKey(0)\nkey,k1,k2=jax.random.split(key,3)\na=jax.random.normal(k1,(3,)); b=jax.random.uniform(k2,(3,))\nprint(a); print(b)", "The same key is reused for separate random draws.", "Split PRNG keys before separate stochastic operations.", ["jax","random","split"]),
        "lax_scan": (30,"jax_performance_fix","Python loop/list accumulation under jit", "import jax\nimport jax.numpy as jnp\n\n@jax.jit\ndef cumulative_sum(xs):\n    total=0.0; outputs=[]\n    for x in xs:\n        total=total+x; outputs.append(total)\n    return jnp.array(outputs)\nprint(cumulative_sum(jnp.array([1.,2.,3.])))", "import jax\nimport jax.numpy as jnp\n\n@jax.jit\ndef cumulative_sum(xs):\n    def step(total,x):\n        total=total+x; return total,total\n    _,ys=jax.lax.scan(step,0.0,xs); return ys\nprint(cumulative_sum(jnp.array([1.,2.,3.])))", "Python list accumulation is a poor fit for jitted loops.", "Use lax.scan for loop-carried state and stacked outputs.", ["jax","lax_scan"]),
    }
    cases=[]; idx=0
    for p,t in templates.items():
        limit, task, err, broken, fixed, root, expl, tags=t
        for h in by.get(p,[])[:limit]:
            cases.append(case(f"repo_mutation_{idx:06d}", task, err, broken, fixed, root, expl, tags, h)); idx+=1
    write_jsonl(out/"repo_grounded_mutation_cases.jsonl", cases); print("mutation cases", len(cases))


def run_code(code):
    f=tempfile.NamedTemporaryFile("w",suffix=".py",delete=False); f.write(code); p=f.name; f.close()
    try: r=subprocess.run(["python",p],capture_output=True,text=True,timeout=30); return r.returncode,r.stdout[-1000:],r.stderr[-2000:]
    except Exception as e: return -999,"",repr(e)
    finally:
        try: os.remove(p)
        except Exception: pass


def cmd_validate(args):
    out=Path(args.out_dir); rows=read_jsonl(out/"repo_grounded_mutation_cases.jsonl"); reports=[]; passed=[]
    for row in rows:
        br=run_code(row["broken_code"]); fx=run_code(row["fixed_code"]); expects=row["task_type"]=="jax_error_fix"; ok=fx[0]==0 and ((br[0]!=0) if expects else True)
        rep={"id":row["id"],"task_type":row["task_type"],"error_type":row["error_type"],"expects_broken_fail":expects,"broken_returncode":br[0],"fixed_returncode":fx[0],"ok":ok,"broken_stderr_tail":br[2][-1000:],"fixed_stderr_tail":fx[2][-1000:]}; reports.append(rep)
        if ok: passed.append(row)
    summary={"total":len(reports),"ok":sum(r["ok"] for r in reports),"failed":sum(not r["ok"] for r in reports),"by_error_type":dict(Counter(r["error_type"] for r in reports)),"failures":[r for r in reports if not r["ok"]][:20]}
    jdump(out/"repo_grounded_mutation_validation_report.json", {"summary":summary,"reports":reports}); write_jsonl(out/"repo_grounded_mutation_cases_passed.jsonl", passed); print(summary)


def cmd_manifest(args):
    root=Path(args.out_dir); files=[]
    for p in sorted(root.rglob("*")):
        if p.is_file() and ".git" not in str(p):
            h=hashlib.sha256(p.read_bytes()).hexdigest(); files.append({"path":str(p.relative_to(root)),"size_bytes":p.stat().st_size,"sha256":h})
    jdump(root/"MANIFEST.json", {"files":files}); print("manifest", len(files))


def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest="cmd", required=True)
    for name in ["discover","plan","clone","extract","score","patterns","mutations","validate","manifest"]:
        sp=sub.add_parser(name); sp.add_argument("--out-dir", required=True)
        if name=="discover": sp.add_argument("--target-per-bucket", type=int, default=50); sp.add_argument("--max-pages-per-query", type=int, default=2)
        if name=="clone": sp.add_argument("--max-clones", type=int, default=60)
    args=ap.parse_args(); globals()["cmd_"+args.cmd](args)

if __name__=="__main__": main()
